package sqlcon;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;


import com.Sqlconnention.mssql.Emp.MyEmployee;

public class SqlConnection {
	@Autowired
	JdbcTemplate JdbcTemplate;
	
	static final String SQL = "select * from Customer";

	public List<MyEmployee> Read() {

		List<MyEmployee> employee = new ArrayList<MyEmployee>();

		List<Map<String, Object>> mymap = JdbcTemplate.queryForList(SQL);

		for (Map<String, Object> row : mymap) {
			MyEmployee emp = new MyEmployee();

			emp.setName((String) row.get("name"));
			emp.setAge((int) row.get("age"));
		
			employee.add(emp);
		}

		return employee;

	}



}
