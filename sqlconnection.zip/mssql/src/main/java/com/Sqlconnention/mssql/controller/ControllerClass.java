package com.Sqlconnention.mssql.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Sqlconnention.mssql.Emp.MyEmployee;

import antlr.collections.List;
import sqlcon.SqlConnection;

@RestController
@RequestMapping("api")
public class ControllerClass {

	@Autowired SqlConnection con;
	
	
	@GetMapping(value = "test")
	public ResponseEntity<?> Employeee()
	{
		
		java.util.List<MyEmployee> employee=con.Read();
		
		return new ResponseEntity<>(employee,HttpStatus.OK);
	
	}
	
}
